package com.example.ion.greedygame_final;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class SplashActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        FragmentOne frag = new FragmentOne();
        fragmentTransaction.add(R.id.fooFragment,frag).commit();


//        FragmentOne ls_fragment = new FragmentOne();
//        FragmentManager fragmentManager = getFragmentManager();
//        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//        fragmentTransaction.add(R.id.fab, ls_fragment).commit();

    }

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}
