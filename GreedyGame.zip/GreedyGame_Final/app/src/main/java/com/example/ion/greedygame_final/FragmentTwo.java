package com.example.ion.greedygame_final;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

/**
 * Created by Ayan on 19/04/17.
 */
public class FragmentTwo extends Fragment {

    ImageView image;

    @Override
    public View onCreateView(LayoutInflater inflater,ViewGroup viewGroup, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_two, viewGroup, false);
        image = (ImageView) view.findViewById(R.id.splash);


        Thread timer = new Thread() {
            public void run() {
                try {
                    Animation animation = AnimationUtils.loadAnimation(getActivity(), R.anim.fade);
                    image.startAnimation(animation);
                    sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    //FragmentTwo fragment = new FragmentTwo();
                    //Intent intent= new Intent(getContext(),HomeActivity.class);
                    //startActivity(intent);
                }
            }
        };
        timer.start();
        return view;
    }

}
