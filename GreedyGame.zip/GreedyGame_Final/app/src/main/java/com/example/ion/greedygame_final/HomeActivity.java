package com.example.ion.greedygame_final;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Ayan on 18/04/17.
 */
public class HomeActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }
}
